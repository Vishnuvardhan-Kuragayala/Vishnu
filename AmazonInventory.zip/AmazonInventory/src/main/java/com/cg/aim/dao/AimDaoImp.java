package com.cg.aim.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.aim.dbutil.Dbutil;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Aimlockerexception;

public class AimDaoImp implements AimDaoDb {
	EntityManager em;
	public AimDaoImp() {
		em=Dbutil.getConnection();
	}
	static int logCount=100;
	public Locker save(LockerLog log) {
		em=Dbutil.getConnection();
		/*em=Dbutil.getConnection();
//		em.persist(locker_log);
		 LockerLog log=new LockerLog();
		 log.setDate(new Date());
		 log.setDescription("ds");
		 log.setId(12);
		 log.setLocker(locker);*/
	
		 log.setDate(new java.sql.Date(System.currentTimeMillis()));
		 em.persist(log);
		 em.getTransaction().commit();
		 em.close();
		return log.getLocker();
	}

	public Locker findById(int id) throws Aimlockerexception {
		try {
		em=Dbutil.getConnection();
		String sql="from Locker where lockerId=:id";
		TypedQuery<Locker> query=em.createQuery(sql,Locker.class);
		query.setParameter("id",id);
		Locker locker=query.getSingleResult();
		return locker;
		}catch(Exception e) {
			throw new Aimlockerexception("Locker not found");
		}finally {
			em.close();
		}
	}
	public List<Locker>showall(){
		em=Dbutil.getConnection();
		Query sqlquery=em.createQuery(" from Locker where Capacity>50");
	//	TypedQuery<Locker> query=em.createQuery(sql,Locker.class);
List<Locker> lockerList=sqlquery.getResultList();
		
		return lockerList;
	}
	
	

	public List<Item> showAll() {
		em=Dbutil.getConnection();
		String sql="select item from Item item";
		TypedQuery<Item> query=em.createQuery(sql,Item.class);
		List<Item> itemList=query.getResultList();
		
		return itemList;
	}

}