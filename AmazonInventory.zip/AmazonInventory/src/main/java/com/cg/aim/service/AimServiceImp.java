package com.cg.aim.service;

import java.util.List;

import com.cg.aim.dao.AimDaoDb;
import com.cg.aim.dao.AimDaoImp;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Aimlockerexception;

public class AimServiceImp implements AimService {
	
	private AimDaoDb dao=null;
	
	public AimServiceImp() {
		dao=new AimDaoImp();
	}

	public Locker add(LockerLog lockerLog) {
		return dao.save(lockerLog) ;
	}

	public List<Item> showAll() {
		return dao.showAll();
	}

	public Locker searchById(int lockerId)  {
		Locker locker=dao.findById(lockerId);
		if(locker==null) {
			throw new Aimlockerexception("Please enter valid locker_Id");
		}
		return locker;
	}

	public LockerLog addLog(LockerLog log) {
		
		return null;
	}

	public List<Locker> showall() {
		return dao.showall();		// TODO Auto-generated method stub
	}
	
}
