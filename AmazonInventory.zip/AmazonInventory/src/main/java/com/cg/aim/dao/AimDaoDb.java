package com.cg.aim.dao;
import java.util.List;

import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Aimlockerexception;
public interface AimDaoDb {
	//Query
public static final String queryInsertLocker ="INSERT INTO LOCKER VALUES(?,?)";

public static final String queryInsertItem ="INSERT INTO ITEM VALUES(?,?,?,?)";

public Locker save(LockerLog lockerLog);	
public Locker findById(int id) throws Aimlockerexception;
public List<Item> showAll();
public List<Locker>showall();
	
}
