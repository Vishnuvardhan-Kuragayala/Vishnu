package com.cg.aim.dbutil;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Dbutil {

	static EntityManager em =null;
	public static EntityManager getConnection() {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("AmazonInventory");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		return em;
	}
} 
