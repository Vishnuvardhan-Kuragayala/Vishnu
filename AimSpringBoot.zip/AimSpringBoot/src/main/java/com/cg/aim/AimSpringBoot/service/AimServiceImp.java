package com.cg.aim.AimSpringBoot.service;


import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.aim.AimSpringBoot.Exception.LockerLogNotFoundException;
import com.cg.aim.AimSpringBoot.dao.AimDao;
import com.cg.aim.AimSpringBoot.dto.LockerLog;
@Service
public class AimServiceImp implements AimService {
	static final Logger logger = Logger.getLogger(AimServiceImp.class);
	
@Autowired
AimDao dao;


/**
 * Written by Vishnu on 27-05-2019
 * last modified on 27-05-2019
 * it adds the Lockerlog,
 */
	@Override
	public LockerLog addloc(LockerLog lockerLog) {
		PropertyConfigurator.configure("D:\\G-104\\spring\\Vishnu-master\\AimSpringBoot\\src\\main\\resources\\log4j.properties"); 
		logger.info("lOCKERlOG added successful");
		
		 
		return  dao.save(lockerLog);
	
	}
	 
	 /**
	  * Written by Vishnu on 04-05-2019
	  * last modified on 27-05-2019
	  * shows all list of items
	  */

	@Override
	public List<LockerLog> showAll() {
		PropertyConfigurator.configure("D:\\G-104\\spring\\Vishnu-master\\AimSpringBoot\\src\\main\\resources\\log4j.properties"); 
		logger.info("DISPLAY ALL LOCKERLOGS");
		
		// TODO Auto-generated method stub
		return dao.findAll();
	}
	 /**
	  * Written by Vishnu on 27-05-2019
	  * last modified on 27-05-2019
	  * finds the lockerlog id whether it is present or not.
	  */
	@Override
	public List<LockerLog> searchById(int id)throws LockerLogNotFoundException {
		PropertyConfigurator.configure("D:\\G-104\\spring\\Vishnu-master\\AimSpringBoot\\src\\main\\resources\\log4j.properties"); 
		logger.info("SEARCHES BY ID");
		
		// TODO Auto-generated method stub
   List<LockerLog> logg=dao.findById(id);
		return logg;

	}

	

}
