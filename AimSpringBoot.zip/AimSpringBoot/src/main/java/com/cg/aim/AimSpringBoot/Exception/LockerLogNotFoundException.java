package com.cg.aim.AimSpringBoot.Exception;

public class LockerLogNotFoundException extends RuntimeException{

	public LockerLogNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public LockerLogNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	
	
}
