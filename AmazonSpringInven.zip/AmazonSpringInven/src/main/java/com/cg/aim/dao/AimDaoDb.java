package com.cg.aim.dao;
import java.util.List;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;
/*
 * 
AimDaoDb Interface  implemented by 
 @Author: Vishnuvardhan
 @Version:1.0
 @Since: 11-05-2019
 */ 
public interface AimDaoDb {
public Locker save(Locker locker);	
public Locker findById(int id) throws Exceptionn;
public  List<Item> showAll();
	
}
