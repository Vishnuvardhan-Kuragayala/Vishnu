package com.cg.aim.service;
import java.util.List;

import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;

/*
 * 
 AimService Interface Simplemented by 
 @Author: Vishnuvardhan
 @Version:1.0
 @Since: 11-05-2019
 */ 
public interface AimService
{
	
	public Locker add(Locker locker);
	public List<Item> showAll();
	public Locker searchById(int lockerId)throws Exceptionn;
	

}
