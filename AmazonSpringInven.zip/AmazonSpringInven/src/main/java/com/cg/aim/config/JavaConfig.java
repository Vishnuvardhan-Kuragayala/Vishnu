package com.cg.aim.config;
/*
 *  @Author: Vishnuvardhan
 @Version:1.0
 @Since: 11-05-2019
 */
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan({"com.cg.aim"})//scans the classes contained in basic package.
public class JavaConfig {

}
