package com.cg.aim.dao;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;
import com.cg.aim.util.DBUtil;
/*
 * 
 AimDaoImp Class implemented by 
 @Author: Vishnuvardhan
 @Version:1.0
 @Since: 11-05-2019
 */ 
@Repository("aimdao")
public class AimDaoImp implements AimDaoDb 
{
List<Locker> Log;

public AimDaoImp()
{
	Log=new ArrayList<Locker>();
}

public Locker save(Locker locker) 
 {
	  DBUtil.lockerList.add(locker);
	  return locker;
  }

public Locker findById(int id) throws Exceptionn 
{
	
	for (Locker locker : DBUtil.lockerList) 
	{
		if(locker.getLockerId()==id) 
		{
			return locker;
		}
	}
	throw new Exceptionn("*************The LOCKERID was not found**********");  
}

public List<Item> showAll() 
  {
	List<Item> items=new ArrayList<Item>();
	for(Locker l: DBUtil.lockerList)
		items.addAll(l.getList());
	return items;
  }


}


