package com.cg.aim.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.aim.dao.AimDaoDb;
import com.cg.aim.dao.AimDaoImp;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;
/*
 * 
 AimServiceImp Class implemented by 
 @Author: Vishnuvardhan
 @Version:1.0
 @Since: 11-05-2019
 */ 
@Service("aimservice")
public class AimServiceImp implements AimService {
	
    @Autowired
	AimDaoDb aimdao;
	public Locker add(Locker locker) {
	return aimdao.save(locker);
	}

	
	public List<Item> showAll() {
		return aimdao.showAll();
	}

	
	
	public Locker searchById(int lockerId) throws Exceptionn {
	return aimdao.findById(lockerId);
	}
}
