package com.cg.aim.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;

public class DBUtil {
	public static List<Locker> lockerList=new ArrayList<Locker>();
	public static List<Item> log=new ArrayList<Item>();
	
	/*public static List<Item> itemList=new ArrayList<Item>();
	public static List<Item> itemList1=new ArrayList<Item>();
	public static List<Item> itemList2=new ArrayList<Item>();
	
	public static LockerLog log=null;
	
	static {
		Item itemone=new Item(100,"Medicine",1001);
		itemList.add(itemone);
		Object items;

		Item itemtwo=new Item(101,"clothes",1002);
		itemList1.add(itemtwo);
		
		Item itemthree=new Item(102,"TOYS",1003);
		itemList2.add(itemthree);
		
log=new LockerLog(new Date()," Vishnu", "Locker1 items", lockerList);
	}*/

}
