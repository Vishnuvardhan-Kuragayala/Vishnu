package com.cg.aim.ui;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.aim.config.JavaConfig;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;
import com.cg.aim.service.AimService;
import com.cg.aim.service.AimServiceImp;
import com.cg.aim.util.DBUtil;
/*
 * 
 MyApplication Class implemented by 
 @Author: Vishnuvardhan
 @Version:1.0
 @Since: 11-05-2019
 */ 

@Component
public class MyApplication {
	static AimService aimservice;
	@Autowired
	AimService ser;
	@PostConstruct
	public void init() {
		aimservice=this.ser;
	}
    public static void main(String[] args) {
	AnnotationConfigApplicationContext app=new AnnotationConfigApplicationContext(JavaConfig.class);
	Locker loc=null;
	Item item=(Item) app.getBean("item");
	LockerLog loclog=(LockerLog) app.getBean("lockerlog");
	Scanner scr=new Scanner(System.in);
			//service=new AimServiceImp();
			int choice=0;
			do {
				printDetails();
				System.out.println("Enter the choice");
				choice=scr.nextInt();
		
				switch(choice) {
				
             case 1:String ch=null;      	
            	 	List<Item> list=new ArrayList<Item>();//Adding the lockers and items in lockers
					/*List<Item> itemList=new ArrayList<Item>();
					Item itemone=new Item(100,"medicine",1001);
					itemList.add(itemone);
					List<Item> itemList1=new ArrayList<Item>();
					Item itemtwo=new Item(101,"clothes",1002);
					itemList1.add(itemtwo);*/
            	 
            	 
            	 //ABOUT LOCKERS*****************
					/*Locker locker=new Locker(111,10,DBUtil.itemList);
					Locker lockerOne=new Locker(222,8,DBUtil.itemList1);
					Locker lockertwo=new Locker(333,6,DBUtil.itemList2);
					
					System.out.println(service.add(locker));
					System.out.println(service.add(lockerOne));
					System.out.println(service.add(lockertwo));*/
            	 System.out.println("enter Locker Id");
            	 int id=scr.nextInt();
            	 System.out.println("capacity");
            	 int cap=scr.nextInt();
           do {
            	   Item it=(Item) app.getBean("item");
            	   System.out.println("Enter a item name");
            	   String name=scr.next();
            	   System.out.println("Enter a requester name");
            	   String reqname=scr.next();
            	   System.out.println("Enter a batch number");
                   int batch=scr.nextInt();
                   System.out.println("Enter a item id");
                   int itemid=scr.nextInt();
                   loc=(Locker) app.getBean("locker");
           	       loc.setLockerId(id);
            	   loc.setCapacity(cap);
            	   it.setId(itemid);
                   // it.setName(name);
            	   it.setName(reqname);
            	   it.setBatchNumber(batch);
            	   loclog.setRequester(reqname);
            	   // System.out.println(loclog);
            	   list.add(it);
            	   System.out.println("Enter more items? (y/n)");
            	   ch=scr.next();
            }while(ch.equalsIgnoreCase("y"));
            	   loc.setList(list);
            	   aimservice.add(loc);
            	   System.out.println(loc);
            	   
            	  break;
					
             case 2:
             
//            	   List<Locker> lockerList=service.showAll();
            	   List<Item> log=aimservice.showAll();//Displays the log
            	    System.out.println(log);
            	   
            	  /* for (Locker locker2 : lockerList) {
				   System.out.println("locker id is "+locker2.getLockerId());
				   System.out.println("locker capacity is "+locker2.getCapacity());
				   }*/
            	   break;
            	   
             case 3:// Searches by LockerId
					System.out.println("enter the locker id to search");
					int Id=scr.nextInt();
					Locker lock=null;
					try {
						lock = aimservice.searchById(Id);
					} 
					catch (Exceptionn e)
					{
						System.out.println(e.getMessage());
					    }
					    if(lock!=null) 
					    {
					       System.out.println(lock);
					        }
				      /*System.out.println("locker id is "+lock.getLockerId());
				       System.out.println("locker capacity "+lock.getCapacity());
				       System.out.println("Item id is "+lock.getList().getId());
					   System.out.println("Item name is "+item.getName());
					   System.out.println("batch number is "+item.getBatchNumber());
						*/
					      break;
				         }
			}
			while(choice!=4);
        }
				private static void printDetails()
		{
				System.out.println("1.Add locker");
				System.out.println("2.show all");
				System.out.println("3.search by locker Id");
				       }
			

		}




