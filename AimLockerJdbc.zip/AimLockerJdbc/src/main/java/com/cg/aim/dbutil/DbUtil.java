package com.cg.aim.dbutil;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


import com.cg.aim.exception.ConnectionException;


public class DbUtil {
	static Connection conn;
	public static Connection getConnection(){
		Properties prop=new Properties();
		InputStream it;
		try {
			it=new FileInputStream("src/main/resources/aimjdbc.properties");
			prop.load(it);
			if(prop!=null) {
				String driver=prop.getProperty("jdbc.driver");
				String url=prop.getProperty("jdbc.url");
				String uname=prop.getProperty("jdbc.username");
				String pass=prop.getProperty("jdbc.password");
				Class.forName(driver);
				conn=DriverManager.getConnection(url,uname,pass);
			}}
		catch(Exception e) {
			throw new ConnectionException("Connection not established");
		}
		return conn;

	}



}

