package com.cg.aim.ui;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Aimlockerexception;
import com.cg.aim.exception.ConnectionException;
import com.cg.aim.service.AimService;
import com.cg.aim.service.AimServiceImp;

public class MyApplication {
	static AimService service;
    public MyApplication() { 
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		service=new AimServiceImp();
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter the choice");
			choice=sc.nextInt();
			int id;
			int capacity;
			String itemName;
			int itemId;
			
			switch(choice) {

			case 1:          //******Adding lockers and items*********
				List<Item> items=new ArrayList<Item>();
				System.out.println("Enter locker id:");
				id=sc.nextInt();
				System.out.println("Enter capacity: ");
				capacity=sc.nextInt();
				
				
				System.out.println("Enter the requester name: ");
				String requester=sc.next();
				System.out.println("Enter the description: ");
				String description=sc.next();
				
				do {
					System.out.println("Enter item id: ");
					itemId=sc.nextInt();
					
					System.out.println("Enter Item Name: ");
					itemName=sc.next();
					
					
					
					System.out.println("Enter batch number: ");
					int batchNumber=sc.nextInt();
					Item item=new Item(itemId, itemName, batchNumber);
					items.add(item);
					
					System.out.println("Do you want to add more item? ");
					System.out.println("press 1 to add/ press 2 for exit");
					choice=sc.nextInt();
				    }
				
				    while(choice!=2);
				    Locker locker=new Locker(id, capacity, items);
				   // LockerLog log=new LockerLog(new Date(), requester, description, locker);
				    System.out.println(service.add(locker));
				    break;

			case 2:     // ******Shows all lockers********

				LockerLog log=service.showAll();
				 for (Locker lock: log.getLocker()) {
				   System.out.println("locker id: "+lock.getLockerId()+"    locker capacity: "+lock.getCapacity());
				   for(Item i:lock.getList()) {
					   System.out.println("name: "+i.getName()+"  batchNumber: "+i.getBatchNumber());
				   	}
				   }
				break;

			case 3:   //******finding by locker Id*******
				System.out.println("enter the locker id to search");
				id=sc.nextInt();
				Locker lock=null;
				try {
					try {
						lock = service.searchById(id);
						if(lock!=null) {
							System.out.println("locker id is "+lock.getLockerId());
							System.out.println("locker capacity "+lock.getCapacity());
							for(Item i:lock.getList()) {
								System.out.println("Item name is "+i.getName());
								System.out.println("batch number is "+i.getBatchNumber());
							}
							//System.out.println("Item id is "+lock.getList().getId());

						}
					} catch (Aimlockerexception e) {
						e.getMessage();
						System.out.println("***THE LOCKER WAS NOT FOUND***");//
						break;
					}
				} catch (ConnectionException e) {
					System.out.println(e.getMessage());
				}
				break;
			}
		}while(choice!=4);
	}
	private static void printDetails() {
		System.out.println("1.Add locker");
		System.out.println("2.show all");
		System.out.println("3.search by locker Id");
	}


}

/*
 * Author:Vishnuvardhan.
 * This Project is about Inventory management that describes how Item can be stored in locker.
 * After storing the Items in Locker,can see which item is present which locker.
 * It also displays the all lockers and items in lockers.
 */
