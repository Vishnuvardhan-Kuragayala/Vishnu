package com.cg.aim.dto;

import java.util.Date;
import java.util.List;

public class LockerLog {
	private Date date;
	private String requester;
	private String Description;
	private List<Locker> locker;
	public LockerLog() {
		super();
		
	}
	public LockerLog(Date date, String requester, String description, List<Locker> locker) {
		super();
		this.date = date;
		this.requester = requester;
		Description = description;
		this.locker = locker;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getRequester() {
		return requester;
	}
	public void setRequester(String requester) {
		this.requester = requester;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public List<Locker> getLocker() {
		return locker;
	}
	public void setLocker(List<Locker> locker) {
		this.locker = locker;
	}
	@Override
	public String toString() {
		return "LockerLog [date=" + date + ", requester=" + requester + ", Description=" + Description + ", locker="
				+ locker + "]";
	}
	
	
	
	}
