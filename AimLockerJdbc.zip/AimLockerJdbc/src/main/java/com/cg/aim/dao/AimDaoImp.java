package com.cg.aim.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.aim.dbutil.DbUtil;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Aimlockerexception;

public class AimDaoImp implements AimDaoDb {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	public Locker save(Locker locker) {
		conn=DbUtil.getConnection();
		try {
			
			pstmt=conn.prepareStatement(AimDaoDb.queryInsertLocker);
			pstmt.setInt(1, locker.getLockerId());
			pstmt.setInt(2, locker.getCapacity());
			pstmt.executeUpdate();
			for(Item i: locker.getList()) {
				
				//queryInsertItem="INSERT INTO ITEM VALUES(?,?,?,?)"
				pstmt=conn.prepareStatement(AimDaoDb.queryInsertItem);
				
				pstmt.setInt(1, i.getId());
				pstmt.setString(2, i.getName());
				pstmt.setInt(3, i.getBatchNumber());
				pstmt.setInt(4, locker.getLockerId());
				int record=pstmt.executeUpdate();
				if(record==1)
				System.out.println("*********Items inserted successfully*********");
			}
			
		} catch (SQLException e) {
			throw new Aimlockerexception("error in showing details");
		}
		finally {
			try {
				pstmt.close();
				conn.close();
				
			}
			catch(SQLException e) {
				throw new Aimlockerexception("error in showing details");
			}
		}
		return locker;
	}
	
	
	public Locker findById(int id) throws Aimlockerexception {
		conn=DbUtil.getConnection();
		List<Item> items=new ArrayList<Item>();
		Locker locker=null;
		Item item=new Item();
		try {
			pstmt=conn.prepareStatement("select l.locker_id, l.capacity, i.item_id, i.name, i.batchnumber from locker l join item i on l.locker_id=i.locker_id where l.locker_id=?");
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			while(rs.next()) {
			locker=new Locker();
			locker.setLockerId(rs.getInt(1));
			locker.setCapacity(rs.getInt(2));
			item.setId(rs.getInt(3));
			item.setName(rs.getString(4));
			item.setBatchNumber(rs.getInt(5));
			items.add(item);
			locker.setList(items);
			}
		} catch (SQLException e) {
			throw new Aimlockerexception("error in showing details");
			}
		finally {
			try {
				pstmt.close();
				conn.close();
				
			}
			catch(SQLException e) {
				throw new Aimlockerexception("error in showing details");
			}
		}
		return locker;
	}
	public LockerLog showAll() {
		conn=DbUtil.getConnection();
		LockerLog log=new LockerLog();
		List<Locker> lockers=new ArrayList<Locker>();
		try {
			
			pstmt=conn.prepareStatement("select l.locker_id, l.capacity, i.item_id, i.name, i.batchnumber from locker l join item i on l.locker_id=i.locker_id");
			rs=pstmt.executeQuery();
			while(rs.next()) {
			
			List<Item> items=new ArrayList<Item>();
			Locker locker=new Locker();
			Item item=new Item();
			locker.setLockerId(rs.getInt(1));
			locker.setCapacity(rs.getInt(2));
			item.setId(rs.getInt(3));
			item.setName(rs.getString(4));
			item.setBatchNumber(rs.getInt(5));
			items.add(item);
			locker.setList(items);
			lockers.add(locker);
			log.setLocker(lockers);
			}
		} catch (SQLException e) {
			throw new Aimlockerexception("error in showing details");
		
		}
		finally {
			try {
				pstmt.close();
				conn.close();
				
			}
			catch(SQLException e) {
				throw new Aimlockerexception("error in showing details");
			}
		}
		return log;
	}
	}
