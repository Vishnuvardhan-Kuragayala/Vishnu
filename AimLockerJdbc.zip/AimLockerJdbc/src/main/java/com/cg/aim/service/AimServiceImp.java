package com.cg.aim.service;

import java.util.List;

import com.cg.aim.dao.AimDaoDb;
import com.cg.aim.dao.AimDaoImp;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Aimlockerexception;

public class AimServiceImp implements AimService {

	private AimDaoDb dao;
	
	public AimServiceImp() {
		dao=new AimDaoImp();
	}

	public Locker add(Locker locker) {
		return dao.save(locker) ;
	}

	public LockerLog showAll() {
		return dao.showAll();
	}

	public Locker searchById(int lockerId)  {
		Locker locker=dao.findById(lockerId);
		if(locker==null) {
			throw new Aimlockerexception("Id not found");
		}
		return locker;
	}
	
}
