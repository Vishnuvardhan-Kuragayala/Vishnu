package com.cg.aim.service;

import java.util.List;

import com.cg.aim.dao.AimDaoDb;
import com.cg.aim.dao.AimDaoImp;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;

public class AimServiceImp implements AimService {
	AimDaoDb dao;
	
	public AimServiceImp() {
		dao=new AimDaoImp(); }

	@Override
	public Locker add(Locker locker) {
	return dao.save(locker);
	}

	@Override
	public LockerLog showAll() {
		return dao.showAll();
	}

	@Override
	public Locker searchById(int lockerId) throws Exceptionn {
	return dao.findById(lockerId);
	}
}
