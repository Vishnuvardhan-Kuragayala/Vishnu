package com.cg.aim.service;
import java.util.List;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;


public interface AimService {
	
	public Locker add(Locker locker);
	public LockerLog showAll();
	public Locker searchById(int lockerId)throws Exceptionn;
	

}
