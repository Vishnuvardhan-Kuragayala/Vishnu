package com.cg.aim.ui;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;
import com.cg.aim.service.AimService;
import com.cg.aim.service.AimServiceImp;
import com.cg.aim.util.DBUtil;
public class MyApplication {
	static AimService service;

	public MyApplication() { 
}
			
public static void main(String[] args) {
	Scanner scr=new Scanner(System.in);
			service=new AimServiceImp();
			int choice=0;
			do {
				printDetails();
				System.out.println("Enter the choice");
				choice=scr.nextInt();
		
				switch(choice) {
				
             case 1:
					/*List<Item> itemList=new ArrayList<Item>();
					Item itemone=new Item(100,"medicine",1001);
					itemList.add(itemone);
					List<Item> itemList1=new ArrayList<Item>();
					Item itemtwo=new Item(101,"clothes",1002);
					itemList1.add(itemtwo);*/
            	 
            	 
            	 //ABOUT LOCKERS*****************
					Locker locker=new Locker(111,10,DBUtil.itemList);
					Locker lockerOne=new Locker(222,8,DBUtil.itemList1);
					Locker lockertwo=new Locker(333,6,DBUtil.itemList2);
					
					System.out.println(service.add(locker));
					System.out.println(service.add(lockerOne));
					System.out.println(service.add(lockertwo));
					break;
					
             case 2:
             
//            	   List<Locker> lockerList=service.showAll();
            	   LockerLog log=service.showAll();
            	   
            	   System.out.println(log);
            	   
            	  /* for (Locker locker2 : lockerList) {
				   System.out.println("locker id is "+locker2.getLockerId());
				   System.out.println("locker capacity is "+locker2.getCapacity());
				   }*/
            	   break;
            	   
             case 3:
					System.out.println("enter the locker id to search");
					
					int id=scr.nextInt();
					Locker lock=null;
					try {
						lock = service.searchById(id);
					} catch (Exceptionn e) {
						// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					}
					if(lock!=null) {
					System.out.println(lock);
				      /*System.out.println("locker id is "+lock.getLockerId());
				       System.out.println("locker capacity "+lock.getCapacity());
				       System.out.println("Item id is "+lock.getList().getId());
					   System.out.println("Item name is "+item.getName());
					   System.out.println("batch number is "+item.getBatchNumber());
						*/
					}break;
				   }
			}while(choice!=4);
}
				private static void printDetails() {
				System.out.println("1.Add locker");
				System.out.println("2.show all");
				System.out.println("3.search by locker Id");
				}
			

		}




