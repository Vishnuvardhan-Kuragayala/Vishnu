package com.cg.aim.dao;
import java.util.ArrayList;
import java.util.List;
import com.cg.aim.dto.Item;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;
import com.cg.aim.util.DBUtil;

public class AimDaoImp implements AimDaoDb {
List<Locker> Log;
public AimDaoImp() {
	Log=new ArrayList<Locker>();
}

@Override
public Locker save(Locker locker) {
	
	DBUtil.lockerList.add(locker);
	return locker;
}
@Override
public Locker findById(int id) throws Exceptionn {
	
	for (Locker locker : DBUtil.lockerList) {
		if(locker.getLockerId()==id) {
			return locker;
		}
	}
	throw new Exceptionn("*************The LOCKERID was not found**********");  
}
@Override
public LockerLog showAll() {
	
	return DBUtil.log;
}

	

}
