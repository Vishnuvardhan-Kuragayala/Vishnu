package com.cg.aim.dao;
import java.util.List;
import com.cg.aim.dto.Locker;
import com.cg.aim.dto.LockerLog;
import com.cg.aim.exception.Exceptionn;
public interface AimDaoDb {

public Locker save(Locker locker);	
public Locker findById(int id) throws Exceptionn;
public LockerLog showAll();
	
}
