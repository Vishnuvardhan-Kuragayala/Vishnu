package com.cg.aim.dto;

import java.util.List;

public class Locker {

	private int lockerId;
	private int capacity;
	private List<Item>list;
	
	
	public Locker() {
		super();
		
	}
	public Locker(int lockerId, int capacity, List<Item> list) {
		super();
		this.lockerId = lockerId;
		this.capacity = capacity;
		this.list = list;
	}

	public int getLockerId() {
		return lockerId;
	}
	
	public void setLockerId(int lockerId) {
		this.lockerId = lockerId;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public List<Item> getList() {//this one
		return list;
	}
	public void setList(List<Item> list) {
		this.list = list;
	}
	@Override
	public String toString() {
		return "Locker [lockerId=" + lockerId + ", capacity=" + capacity + ", list=" + list + "]";
	}
	
	
}
