package com.cg.aim.exception;

public class Exceptionn extends Exception {
	public Exceptionn() {
	super();
	}	
	
	public Exceptionn(String s) {
			
		super(s);
	}	

}
